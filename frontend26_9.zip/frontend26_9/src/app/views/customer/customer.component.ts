import { ListItem } from './../../models/list-item';
import { PnotifyService } from './../../utils/pnotify.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { CustomerTypeService } from './../../services/customer-type.service';
import { CustomerType } from './../../models/customer-type';
import { CustomerService } from './../../services/customer.service';
import { Page } from './../../models/page';
import { Customer } from './../../models/customer';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {
  @ViewChild('editModal', { static: false }) editModal: ModalDirective;
  customerTypes: ListItem[] = [];
  customers: Customer[] = [];
  customer: Customer = {id: 0} as Customer;
  customerTypeId: number = 0;
  page = {pageNumber: 0, pageSize: 3} as Page;
  form: FormGroup;
  constructor(private customerTypeService: CustomerTypeService,
    private fb: FormBuilder,
    private customerService: CustomerService, private pNotifyService: PnotifyService) {
      this.customerTypeService.list().subscribe(res => {
        this.customerTypes = res.data.map( x => ({value: x.id, name: x.name}));
      });
    this.form = this.fb.group({
      CUT_ID: ['', Validators.required],
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      phone: [''],
      email: ['', Validators.email],
      address: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.loadCustomer();
  }
  openAdd() {
    this.customer = {id: 0} as Customer;
    this.editModal.show();
  }
  openEdit(id: number) {
    this.customerService.get(id).subscribe(res => {
      this.customer = res.data;
      // this.form.patchValue(this.customer);
      this.editModal.show();
    });
  }
  delete(id: number) {
    this.pNotifyService.confirm('Confirm', 'Are you sure?', yes => {
      if (yes) {
        this.customerService.delete(id).subscribe(res => {
          if (res.errorCode === 0) {
            this.page.pageNumber = 0; // load first page
            this.loadCustomer();
          }
        });
      }
    });
  }
  loadCustomer(page = null) {
      if (page != null) {
        this.page.pageNumber = page.offset;
      }
    // tslint:disable-next-line: triple-equals
    if (this.customerTypeId == 0) {
      this.customerService.list(this.page).subscribe(res => {
        this.page = res.pageInfo;
        this.customers = res.data;
      });
    } else {
      this.customerService.listByCustomerType(this.customerTypeId, this.page).subscribe(res => {
        this.page = res.pageInfo;
        this.customers = res.data;
      });
    }
  }
  hideModal() {
    this.editModal.hide();
  }
  save() {
    console.log(this.customer);
    this.customerService.save(this.customer).subscribe( res => {
      if (res.errorCode === 0) {
        this.pNotifyService.success('Info', 'Save successful');
        this.editModal.hide();
        this.loadCustomer();
      } else {
        this.pNotifyService.error('Error', 'Save failed');
      }
    }, err => {
      this.pNotifyService.error('Error', 'Save failed');
    });
  }
}
