export interface Login {
    id: number;
    userName: string;
    fullName: string;
    token: string;
}
