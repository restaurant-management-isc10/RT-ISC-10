import { CustomerType } from './customer-type';

export interface Customer {
    id: number;
    CUT_ID: string;
    commission: number;
    name: string;
    phone: string;
    email: string;
    address: string;
    customerType: CustomerType;
}
