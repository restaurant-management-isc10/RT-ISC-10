export interface MaterialType {
    id: number;
    name: string;

}
