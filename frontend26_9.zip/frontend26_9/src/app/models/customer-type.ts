export interface CustomerType {
    id: number;
    name: string;
    commission: number;
}
