export interface MenuType {
    id: number;
    name: string;
}
