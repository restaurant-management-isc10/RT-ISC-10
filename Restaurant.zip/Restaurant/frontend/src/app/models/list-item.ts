export interface ListItem {
    value: any;
    name: string;
}
