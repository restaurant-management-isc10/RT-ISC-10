export interface TableDetail {
    id: number;
    position: string;
}
