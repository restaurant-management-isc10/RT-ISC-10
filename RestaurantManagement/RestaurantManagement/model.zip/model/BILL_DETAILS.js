module.exports = (sequelize, type) => {
    return sequelize.define('BILL_DETAILS', {
        B_ID: {
            type: type.INTEGER,
            primaryKey: true,
        },
        M_ID: {
            type: type.STRING(8),
            primaryKey: true
        },
        BD_Count: {
            type: type.INTEGER,
        },
        BD_Price: {
            type : type.FLOAT
        }
    }, {
        timestamps: false
    })
}