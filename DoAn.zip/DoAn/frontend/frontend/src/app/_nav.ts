interface NavAttributes {
    [propName: string]: any;
}
interface NavWrapper {
  attributes: NavAttributes;
  element: string;
}
interface NavBadge {
  text: string;
  variant: string;
}
interface NavLabel {
  class?: string;
  variant: string;
}

export interface NavData {
  name?: string;
  url?: string;
  icon?: string;
  badge?: NavBadge;
  title?: boolean;
  children?: NavData[];
  variant?: string;
  attributes?: NavAttributes;
  divider?: boolean;
  class?: string;
  label?: NavLabel;
  wrapper?: NavWrapper;
}

export const navItems: NavData[] = [
  {
    name: 'Home',
    url: '/dashboard',
    icon: 'icon-speedometer',
  },
  {
    name: 'Account',
    url: '/account',
    icon: 'icon-list',
    children: [
      {
        name: 'User',
        url: '/account/user',
        icon: 'icon-user'
      },
      {
        name: 'Customer Type',
        url: '/account/customer-type',
        icon: 'icon-list'
      },
      {
        name: 'Customer',
        url: '/account/customer',
        icon: 'icon-people'
      },
    ]
  },
  {
    name: 'Menu',
    url: '/list-menu',
    icon: 'icon-user',
    children: [
      {
      name: 'Menu',
      url: '/list-menu/menu',
      icon: 'icon-list',
    },
    {
      name: 'Menu Type',
      url: '/list-menu/menu-type',
      icon: 'icon-list',
    }
    ]
  },
  {
    name: 'Table Detail',
    url: '/table-detail',
    icon: 'icon-list',
  },
{
    name: 'Employee',
    url: '/employee',
    icon: 'icon-user'
  },
  {
    name: 'Bill',
    url: '/bill',
    icon: 'icon-list'
  }
  //   children: [
  //     {
  //     name: 'Menu',
  //     url: '/list-menu/menu',
  //     icon: 'icon-list',
  //   },
  //   {
  //     name: 'Menu Type',
  //     url: '/list-menu/menu-type',
  //     icon: 'icon-list',
  //   }
  //   ]
  // },
];
