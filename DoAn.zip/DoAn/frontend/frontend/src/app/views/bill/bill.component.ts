import { EmployeeService } from './../../services/employee.service';
import { Employee } from './../../models/employee';
import { BillService } from './../../services/bill.service';
import { Bill } from './../../models/bill';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Page } from './../../models/page';
@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.scss']
})
export class BillComponent implements OnInit {
  @ViewChild('editModal', { static: false }) editModal: ModalDirective;
  employees: Employee[] = [];
  bills: Bill[] = [];
  bill: Bill = {id: 0} as Bill;
  employeeId: number = 0;
  page = {pageNumber: 0, pageSize: 3} as Page;
  columns = [
    {name: 'ID', sortable: true},
    { name: 'Date', sortable: true },
    { name: 'Payment', sortable: true },
    { name: 'Name', sortable: true }

  ];
  constructor(private employeeService: EmployeeService,
    private billService: BillService) {
      this.employeeService.list().subscribe(res => {
       this.employees = res.data;
      });
  }

  ngOnInit() {
    this.loadBill();
  }
  openAdd() {
    this.bill = {id: 0} as Bill;
    this.editModal.show();
  }
  loadBill(page = null) {
      if (page != null) {
        this.page.pageNumber = page.offset;
      }
    // tslint:disable-next-line: triple-equals
    if (this.employeeId == 0) {
      this.billService.list(this.page).subscribe(res => {
        this.page = res.pageInfo;
        this.bills = res.data;
      });
    } else {
      console.log('da vao' + this.employeeId);
       this.billService.listByCustomerType(this.employeeId, this.page).subscribe(res => {
        this.page = res.pageInfo;
        this.bills = res.data;
      });
    }
  }
  hideModal() {
    this.editModal.hide();
  }
  save() {

  }
}
