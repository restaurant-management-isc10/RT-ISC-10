import { ActivatedRoute, Router } from '@angular/router';
import { PnotifyService } from './../../utils/pnotify.service';
import { Component, OnInit } from '@angular/core';
import { TableDetailService } from './../../services/table-detail.service';
import { TableDetail } from './../../models/table-detail';

@Component({
  selector: 'app-table-detail-edit',
  templateUrl: './table-detail-edit.component.html',
  styleUrls: ['./table-detail-edit.component.scss']
})
export class TableDetailEditComponent implements OnInit {
  id: string;
  tableDetail: TableDetail = { id: 0} as TableDetail;
  constructor(private activeRoute: ActivatedRoute, private router: Router,
              private tableDetailService: TableDetailService,
              private pNotifyService: PnotifyService) {
    this.id = this.activeRoute.snapshot.paramMap.get('id');

    if (this.id !== '0') {
      this.tableDetailService.get(this.id).subscribe( res => {
        this.tableDetail = res.data;
      });
    }
  }

  ngOnInit() {
  }

  save() {
    this.tableDetailService.save(this.tableDetail).subscribe( res => {
      if (res.errorCode === 0) {
        this.pNotifyService.success('Info', 'Save successful');
        this.router.navigate(['/customer-type']);
      } else {
        this.pNotifyService.error('Error', 'Save failed');
      }
    }, err => {
      this.pNotifyService.error('Error', 'Save failed');
    });
  }
}
