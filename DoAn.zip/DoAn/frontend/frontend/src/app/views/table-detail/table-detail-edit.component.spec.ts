import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableDetailEditComponent } from './table-detail-edit.component';

describe('TableDetailEditComponent', () => {
  let component: TableDetailEditComponent;
  let fixture: ComponentFixture<TableDetailEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableDetailEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableDetailEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
