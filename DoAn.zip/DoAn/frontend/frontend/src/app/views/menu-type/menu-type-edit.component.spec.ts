import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuTypeEditComponent } from './menu-type-edit.component';

describe('MenuTypeEditComponent', () => {
  let component: MenuTypeEditComponent;
  let fixture: ComponentFixture<MenuTypeEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuTypeEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuTypeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
