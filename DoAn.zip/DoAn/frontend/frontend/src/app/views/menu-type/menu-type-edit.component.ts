import { MenuTypeService } from './../../services/menu-type.service';
import { MenuType } from './../../models/menu-type';
import { ActivatedRoute, Router } from '@angular/router';
import { PnotifyService } from './../../utils/pnotify.service';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-menu-type-edit',
  templateUrl: './menu-type-edit.component.html',
  styleUrls: ['./menu-type-edit.component.scss']
})
export class MenuTypeEditComponent implements OnInit {
  id: string;
  menuType: MenuType = { id: 0} as MenuType;
  constructor(private activeRoute: ActivatedRoute, private router: Router,
              private menuTypeService: MenuTypeService,
              private pNotifyService: PnotifyService) {
    this.id = this.activeRoute.snapshot.paramMap.get('id');

    if (this.id !== '0') {
      this.menuTypeService.get(this.id).subscribe( res => {
        this.menuType = res.data;
      });
    }
  }

  ngOnInit() {
  }

  save() {
    this.menuTypeService.save(this.menuType).subscribe( res => {
      if (res.errorCode === 0) {
        this.pNotifyService.success('Info', 'Save successful');
        this.router.navigate(['/customer-type']);
      } else {
        this.pNotifyService.error('Error', 'Save failed');
      }
    }, err => {
      this.pNotifyService.error('Error', 'Save failed');
    });
  }
}
