import { ModalDirective } from 'ngx-bootstrap/modal';
import { CustomerTypeService } from './../../services/customer-type.service';
import { CustomerType } from './../../models/customer-type';
import { CustomerService } from './../../services/customer.service';
import { Page } from './../../models/page';
import { Customer } from './../../models/customer';
import { Component, OnInit, ViewChild } from '@angular/core';
import { PnotifyService } from '../../utils/pnotify.service';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {

  @ViewChild('editModal', { static: false }) editModal: ModalDirective;
  customerTypes: CustomerType[] = [];
  customers: Customer[] = [];
  customer: Customer = {id: 0} as Customer;
  customerTypeId: number = 0;
  page = {pageNumber: 0, pageSize: 3} as Page;
  columns = [
    { name: 'Name',  sortable: true },
    { name: 'Phone', sortable: true },
    { name: 'Email', sortable: true },
    { name: 'Address', sortable: true },
    { name: 'Action', prop: 'ID', sortable: true }
  ];
  constructor(private customerTypeService: CustomerTypeService,
    private pNotifyService: PnotifyService, private customerService: CustomerService) {
      this.customerTypeService.list().subscribe(res => {
        this.customerTypes = res.data;
      });
  }

  ngOnInit() {
    this.loadCustomer();
  }
  openAdd() {
    this.customer = {id: 0} as Customer;
    this.editModal.show();
  }
  openEdit(event, id) {
    event.preventDefault();
    this.customerService.get(id).subscribe( res => {
      this.customer = res.data;
      this.editModal.show();
    });
  }
  delete(event, id) {
    event.preventDefault();
    this.pNotifyService.confirm('confirm', 'Are you sure ?', yes => {
      if (yes) {
        this.customerService.delete(id).subscribe( res => {
          if (res.errorCode === 0) {
            this.loadCustomer();
          }
        });
      }
    });
  }
  loadCustomer(page = null) {
      if (page != null) {
        this.page.pageNumber = page.offset;
      }
    // tslint:disable-next-line: triple-equals
    if (this.customerTypeId == 0) {
      this.customerService.list(this.page).subscribe(res => {
        this.page = res.pageInfo;
        this.customers = res.data;
      });
    } else {
      console.log('da vao' + this.customerTypeId);
       this.customerService.listByCustomerType(this.customerTypeId, this.page).subscribe(res => {
        this.page = res.pageInfo;
        this.customers = res.data;
      });
    }
  }
  hideModal() {
    this.editModal.hide();
  }
  save() {
    this.customerService.save(this.customer).subscribe(res => {
      if (res.errorCode === 0) {
        this.pNotifyService.success('Info', 'Save successful');
        this.editModal.hide();
        this.loadCustomer();
      } else {
        this.pNotifyService.error('Error', 'Save failed');
      }
    }, err => {
      this.pNotifyService.error('Error', 'Save failed');
    });
  }
}
