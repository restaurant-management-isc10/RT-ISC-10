import { BillComponent } from './views/bill/bill.component';
import { EmployeeComponent } from './views/employee/employee.component';
import { Employee } from './models/employee';
import { MenuEditComponent } from './views/menu/menu-edit.component';
import { AppGuard } from './app.guard';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Import Containers
import { DefaultLayoutComponent } from './containers';

import { P404Component } from './views/error/404.component';
import { P500Component } from './views/error/500.component';
import { LoginComponent } from './views/login/login.component';
import { RegisterComponent } from './views/register/register.component';
import { CustomerTypeComponent } from './views/customer-type/customer-type.component';
import { CustomerComponent } from './views/customer/customer.component';
import { UserComponent } from './views/user/user.component';
import { CustomerTypeEditComponent } from './views/customer-type/customer-type-edit.component';
import { TableDetailEditComponent } from './views/table-detail/table-detail-edit.component';
import { TableDetailComponent } from './views/table-detail/table-detail.component';


export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  },
  {
    path: '404',
    component: P404Component,
    data: {
      title: 'Page 404'
    }
  },
  {
    path: '500',
    component: P500Component,
    data: {
      title: 'Page 500'
    }
  },
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'Login Page'
    }
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    canActivate: [AppGuard],
    children: [
      {
        path: 'account/customer-type',
        component: CustomerTypeComponent,
        data: {
          title: 'Customer Type'
        }
      },
      {
        path: 'account/customer-type/:id',
        component: CustomerTypeEditComponent
      },
      {
        path: 'account/customer',
        component: CustomerComponent,
        data: {
          title: 'Customer'
        }
      },
   {
        path: 'account/user',
        component: UserComponent,
        data: {
          title: 'User'
        }
      },
      {
        path: 'employee',
        component: EmployeeComponent,
        data: {
          title: 'Employee'
        }
      },
      {
        path: 'table-detail',
        component: TableDetailComponent,
        data: {
          title: 'Table Detail'
        }
      },
      {
        path: 'table-detail/:id',
        component: TableDetailEditComponent
      },
      {
        path: 'bill',
        component: BillComponent,
        data: {
          title: 'Bill'
        }
      },
      {
        path: 'dashboard',
        loadChildren: () => import('./views/dashboard/dashboard.module').then(m => m.DashboardModule)
      }
    ]
  },
  { path: '**', component: P404Component }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
