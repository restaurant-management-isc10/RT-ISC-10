export interface Page {
    pageNumber: number;
    pageSize: number;
    totalRows: number;
    totalPages: number;
}
