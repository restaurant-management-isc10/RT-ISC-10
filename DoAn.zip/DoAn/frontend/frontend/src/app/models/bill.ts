export interface Bill {
    id: number;
    E_ID: string;
    date: Date;
    payment: number;

}
