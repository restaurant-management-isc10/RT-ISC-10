import { MenuType } from './menu-type';

export interface Menu {
    id: number;
    MT_ID: number;
    name: string;
    price: string;
    image: string;
    menuType: MenuType;

}
