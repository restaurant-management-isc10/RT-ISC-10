import { Employee } from './employee';
export interface CustomerType {
    id: number;
    name: string;
    commission: number;
    employee: Employee;
}
