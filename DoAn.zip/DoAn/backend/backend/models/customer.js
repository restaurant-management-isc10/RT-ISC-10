module.exports = (sequelize, type) => {
    return sequelize.define('CUSTOMERS', {
        id: {
            field: 'CUS_ID',
            type: type.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        CUT_ID: { type: type.INTEGER, allowNull: false },
        name: {
            field: 'CUS_Name',
            type: type.STRING,
            allowNull: false
        },
        phone: {
            field: 'CUS_Phone',
            type :type.STRING
        },
        email: {
            field: 'CUS_Email',
            type: type.STRING
        },
        address: {
            field: 'CUS_Address',
            type: type.STRING
        }
    }, { timestamps: false, freezeTableName: true })
}

