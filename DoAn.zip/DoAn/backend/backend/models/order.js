module.exports = (sequelize, type) => {
    return sequelize.define('ORDERS', {
        id: {
            field: 'O_ID',
            type: type.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        m_id: {
            field: 'M_ID',
            type: type.INTEGER,
            allowNull: false
         },
         td_id: {
            field: 'TD_ID',
            type: type.INTEGER,
            allowNull: false
         },
       count: {
            field: 'O_Count',
             type: type.INTEGER
         
        }
        
    }, { timestamps: false, freezeTableName: true })
}

