const Sequelize = require('sequelize');
const UserModel = require('./user');
const CustomerTypeModel = require('./customer_type');
const CustomerModel = require('./customer');
const MenuTypeModel = require('./menu_types');
const TableDetailModel = require('./table_detail');
const MenuModel = require('./menu');
const PromoteModel = require('./promote');
// const OrderModel = require('./order');
const MaterialTypeModel = require('./material_type.js');
const MaterialModel = require('./material');
// const IngredientModel = require('./ingredient');
const EmployeeModel = require('./employee');
const BillModel = require('./bill');



const sequelize = new Sequelize('backend', 'sa', '12345', {
    dialect: 'mssql',
    host: 'localhost',
    dialectOptions: {
      options: {
          instanceName: 'SQLEXPRESS'
      }
    },
    pool: {  max: 20,  min: 0,  acquire: 30000,  idle: 10000  },
    logging: true
});

const User = UserModel(sequelize, Sequelize);
const CustomerType = CustomerTypeModel(sequelize, Sequelize);
const Customer = CustomerModel(sequelize, Sequelize);
const MenuType = MenuTypeModel(sequelize,Sequelize);
const TableDetail =TableDetailModel(sequelize,Sequelize);
const Menu = MenuModel(sequelize,Sequelize);
const Promote = PromoteModel(sequelize,Sequelize);
// const Order = OrderModel(sequelize,Sequelize);
const Material = MaterialModel(sequelize,Sequelize);
const MaterialType = MaterialTypeModel(sequelize,Sequelize);
// const Ingredient = IngredientModel(sequelize,Sequelize);
const Employee = EmployeeModel(sequelize,Sequelize);
const Bill = BillModel(sequelize,Sequelize);
//cap1
Customer.belongsTo(CustomerType, {foreignKey: 'CUT_ID', as: 'customerType'});
CustomerType.hasMany(Customer, {foreignKey: 'CUT_ID', as: 'customers'});
// cap3
Menu.belongsTo(MenuType, {foreignKey: 'MT_ID', as: 'menuType'});
MenuType.hasMany(Menu, {foreignKey: 'MT_ID', as: 'menus'});
//cap2
Promote.belongsTo(Menu, {foreignKey: 'M_ID', as: 'menus'});
Menu.hasMany(Promote, {foreignKey: 'M_ID', as: 'promote'});
//cap 4
// Order.belongsTo(Menu, {foreignKey: 'M_ID', as: 'menus'});
// Order.belongsTo(TableDetail,{foreignKey:'TD_ID', as:'tableDetails'});
// Menu.hasMany(Order, {foreignKey: 'M_ID', as: 'order'});
// TableDetail.hasMany(Order, {foreignKey: 'TD_ID', as: 'order'});
//cap 5
Material.belongsTo(MaterialType, {foreignKey: 'MA_T_ID', as: 'materialType'});
MaterialType.hasMany(Material, {foreignKey: 'MA_T_ID', as: 'materials'});
//cap 6
// Ingredient.belongsTo(Menu, {foreignKey: 'M_ID', as: 'menus'});
// Ingredient.belongsTo(Material,{foreignKey:'MA_ID', as:'materials'});
// Menu.hasMany(Ingredient, {foreignKey: 'M_ID', as: 'ingredients'});
// Material.hasMany(Ingredient, {foreignKey: 'MA_ID', as: 'ingredients'});
//cap 7
Bill.belongsTo(Employee, {foreignKey: 'E_ID', as: 'employee'});
Employee.hasMany(Bill, {foreignKey: 'E_ID', as: 'bills'});


// only run once, then comment out
// sequelize.sync({ force: true }).then(() => {
//     console.log(`Database & tables created!`)
// });

module.exports = {
  User,
  CustomerType,
  Customer,
  MenuType,
  TableDetail,
  Menu,
  Promote,
  // Order,
  Material,
  MaterialType,
  // Ingredient
  Employee,
  Bill
}


